from django.apps import AppConfig


class DisplaytimeConfig(AppConfig):
    name = 'displaytime'
