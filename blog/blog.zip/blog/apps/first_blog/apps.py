from django.apps import AppConfig


class FirstBlogConfig(AppConfig):
    name = 'first_blog'
